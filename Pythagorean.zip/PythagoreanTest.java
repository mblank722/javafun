public class PythagoreanTest {
  public static void main (String[] args){
    int sideA = 3;
    int sideB = 4;
    double sideC;
    sideC = Pythagorean.calculateHypotenuse(sideA, sideB);

    System.out.println("Hypotenuse is: " + sideC);


  }
}
