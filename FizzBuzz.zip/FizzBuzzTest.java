public class FizzBuzzTest {
  public static void main (String[] args){

    for(int i=1; i< 35; i++){
      FizzBuzz.fizzBuzz(i);
    }
  }
}
